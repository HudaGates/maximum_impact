<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\StepController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\StrategyController;
use App\Http\Controllers\InvestorController;
use App\Http\Controllers\InvestmentController;

Route::get('/', function () {
    return redirect('/step1');
});

Route::get('/account/setup', [AccountController::class, 'setup']);

Route::get('/account/success', [AccountController::class, 'success']);

Route::get('/step8', [StepController::class, 'showStep8'])->name('step8');
Route::post('/step8', [StepController::class, 'submitStep8'])->name('step8.submit');
Route::get('/step9', [StepController::class, 'showStep9'])->name('step9');

Route::post('/step9', [StepController::class, 'submitStep9'])->name('step9.submit');
Route::get('/account/setup', [StepController::class, 'showAccountSetup'])->name('account.setup');

Route::get('/step1', [StepController::class, 'showStep1'])->name('step1');
Route::post('/step1', [StepController::class, 'submitStep1'])->name('step1.submit');
Route::get('/step2', [StepController::class, 'showStep2'])->name('step2');

Route::get('/step2', [StepController::class, 'showStep2'])->name('step2');
Route::post('/step2', [StepController::class, 'submitStep2'])->name('step2.submit');
Route::get('/step3', [StepController::class, 'showStep3'])->name('step3');

Route::get('/step3', [StepController::class, 'showStep3'])->name('step3');
Route::post('/step3', [StepController::class, 'submitStep3'])->name('step3.submit');
Route::get('/step4', [StepController::class, 'showStep4'])->name('step4');

Route::get('/step4', [StepController::class, 'showStep4'])->name('step4');
Route::post('/step4', [StepController::class, 'submitStep4'])->name('step4.submit');
Route::get('/step5', [StepController::class, 'showStep5'])->name('step5');

Route::get('/step5', [StepController::class, 'showStep5'])->name('step5');
Route::post('/step5', [StepController::class, 'submitStep5'])->name('step5.submit');
Route::get('/step6', [StepController::class, 'showStep6'])->name('step6');

Route::get('/step6', [StepController::class, 'showStep6'])->name('step6');
Route::post('/step6', [StepController::class, 'submitStep6'])->name('step6.submit');
Route::get('/step7', [StepController::class, 'showStep7'])->name('step7');

Route::get('/step7', [StepController::class, 'showStep7'])->name('step7');
Route::post('/step7', [StepController::class, 'submitStep7'])->name('step7.submit');
Route::get('/step8', [StepController::class, 'showStep8'])->name('step8');

Route::get('/myproject', [ProjectController::class, 'index'])->name('myproject.index');

Route::get('/strategy', [StrategyController::class, 'index'])->name('strategy.index');

Route::get('/community', [InvestorController::class, 'index'])->name('investor.index');
Route::get('/community/find-investor-2', [InvestorController::class, 'findInvestor'])->name('community.find-investor-2');
Route::get('/community/investor/{id}', [InvestorController::class, 'show'])->name('investor.profile');

Route::get('/investment', [InvestmentController::class, 'approve'])->name('investment.approve');
Route::get('/investment/{id}/details', [InvestmentController::class, 'show'])->name('investment.details');
Route::get('/investment/status', [InvestmentController::class, 'status'])->name('investment.status');