<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Approval Pending</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8fafc;
            color: #1e293b;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 2rem;
            line-height: 1.5;
        }
        
        .waiting-container {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            padding: 2.5rem;
            max-width: 500px;
            text-align: center;
        }
        
        h1 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            color: #1e293b;
        }
        
        p {
            margin-bottom: 1.5rem;
            color: #64748b;
        }
        
        .home-link {
            display: inline-block;
            margin-top: 2rem;
            color: #3b82f6;
            text-decoration: none;
            font-weight: 500;
        }
        
        .home-link:hover {
            text-decoration: underline;
        }
        
        .help-link {
            margin-top: 3rem;
            display: block;
            color: #64748b;
            font-size: 0.875rem;
        }
    </style>
</head>
<body>
    <div class="waiting-container">
        <h1>We're Putting the Final<br>Touches on Your Account!</h1>
        
        <p>
            Thanks for trusting us with your business journey! Our team is double-
            checking your details to ensure everything is set up perfectly. We'll notify you
            via email as soon as you're approved (usually within 24 hours)
        </p>
        
        <p>
            Great things take a little time, but we promise it'll be worth the wait!
        </p>
        
        <a href="<?php echo e(route('home')); ?>" class="home-link">Return to Home</a>
        
        <a href="<?php echo e(route('help')); ?>" class="help-link">Need Help?</a>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\myapp\resources\views/waiting-approval.blade.php ENDPATH**/ ?>