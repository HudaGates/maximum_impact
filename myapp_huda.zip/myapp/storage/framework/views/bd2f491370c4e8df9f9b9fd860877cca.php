<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Projects</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
        .sidebar {
            width: 60px;
            background-color: #f8f9fa;
            height: 100vh;
        }
        .sidebar-icon {
            display: block;
            padding: 20px;
            text-align: center;
            font-size: 20px;
        }
        .project-card {
            border: 1px solid #eee;
            border-radius: 12px;
            padding: 15px;
            transition: 0.2s ease;
        }
        .project-card:hover {
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .custom-chart {
            height: 200px;
            background-color: #fff;
            border-radius: 12px;
        }
    </style>
</head>
<body>

<div class="d-flex">
    <!-- Sidebar -->
    <div class="sidebar d-flex flex-column align-items-center" style="height: 100vh; background-color: #f8f9fa; padding-top: 20px;">
        <a href="/dashboard" class="sidebar-icon mb-4 text-dark" title="Dashboard">
            <i class="bi bi-grid fs-4"></i>
        </a>
        <a href="/users" class="sidebar-icon mb-4 text-dark" title="Users">
            <i class="bi bi-people fs-4"></i>
        </a>
        <a href="/myproject" class="sidebar-icon mb-4 text-dark" title="myproject">
            <i class="bi bi-bar-chart fs-4"></i>
        </a>
    </div>

    <!-- Main Content -->
    <div class="flex-grow-1 p-4">
        <nav>
            <small>
                <a href="<?php echo e(url('/')); ?>" class="text-decoration-none text-dark">Home</a> / My Projects
            </small>
        </nav>        

        <h2 class="fw-bold mt-3">My Projects</h2>

        <div class="row mt-4">
            <!-- Kiri: Logo dan info + badge -->
            <div class="col-md-4 d-flex flex-column">
                <!-- Info Lion Bird -->
                <div class="d-flex align-items-center mb-3">
                    <img src="<?php echo e(asset('images/lion.png')); ?>" width='100px' class="me-3" alt="avatar">
                    <div>
                        <h6 class="mb-0 fw-semibold">Lion Bird</h6>
                        <small class="text-muted">Smart Robotics for Construction Sites</small>
                    </div>
                </div>
        
                <!-- Badge: Tambahkan margin atas -->
                <div class="shadow rounded bg-white p-3 d-inline-flex align-items-center mt-4" style="width: fit-content;">
                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px; background-color: #1e266d">
                        <i class="bi bi-diagram-3"></i>
                    </div>
                    <div>
                        <div class="text-muted small" >Project Amount</div>
                        <strong>312 Projects</strong>
                    </div>
                </div>
            </div>
        
            <!-- Kanan: Chart -->
            <div class="col-md-8">
                <div class="custom-chart">
                    <h6 class="text-center fw-bold" style="margin-top: 100px">Projects Ammount</h6>
                    <div class="d-flex justify-content-center align-items-end">
                        <img src="<?php echo e(asset('images/bg-pattern.png')); ?>" width="100%" height="200px" alt="chart">
                    </div>
                </div>
            </div>
        </div>
<br><br><br>

        <h4 class="fw-bold text-center mb-4">Project lists</h4>

        <div class="row row-cols-1 row-cols-md-3 g-4">
            <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="project-card">
                        <img src="<?php echo e($project['image']); ?>" alt="Project Image" class="img-fluid rounded mb-3" style="width:400px; height: 200px; object-fit: cover;">
                        <p class="text-muted small mb-1"><?php echo e($project['category']); ?></p>
                        <h6 class="fw-bold"><?php echo e($project['title']); ?></h6>
                        <p class="small text-muted"><?php echo e($project['desc']); ?></p>
                        <div class="d-flex justify-content-between small text-muted">
                            <span><i class="bi bi-clock me-1"></i><?php echo e($project['date']); ?></span>
                            <span><i class="bi bi-eye me-1"></i><?php echo e($project['views']); ?></span>
                        </div>
                    </div>
                    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="text-center mt-5">
            <button class="px-5 py-2 text-white rounded" style="background-color: #1e266d; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1); border: none;">
                Register New Project
            </button>
        </div>
    </div>
</div>

<!-- Bootstrap Icons & JS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\myapp\resources\views/myproject/my-project.blade.php ENDPATH**/ ?>