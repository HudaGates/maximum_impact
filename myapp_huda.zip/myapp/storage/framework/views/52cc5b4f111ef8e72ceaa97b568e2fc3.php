 

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h2 class="fw-bold mb-4">Aprove or Reject Investment</h2>

    <div class="mb-3 w-25">
        <select class="form-select">
            <option selected>Filter by Status</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
        </select>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="text-center align-middle">
                <tr>
                    <th style="background-color: #1F2A69; color: white; border-top-left-radius: 12px;">Investor</th>
                    <th style="background-color: #1F2A69; color: white;">Amount</th>
                    <th style="background-color: #1F2A69; color: white;">Investment Date</th>
                    <th style="background-color: #1F2A69; color: white;">Funding Type</th>
                    <th style="background-color: #1F2A69; color: white;">Investment Type</th>
                    <th style="background-color: #1F2A69; color: white;">Sender</th>
                    <th style="background-color: #1F2A69; color: white;">Origin Bank</th>
                    <th style="background-color: #1F2A69; color: white;">Destination Bank</th>
                    <th style="background-color: #1F2A69; color: white;">Status</th>
                    <th style="background-color: #1F2A69; color: white; border-bottom-right-radius: 12px;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->investor); ?></td>
                    <td><?php echo e(number_format($item->amount, 0, ',', '.')); ?> IDR</td>
                    <td><?php echo e(\Carbon\Carbon::parse($item->date)->format('d M Y')); ?></td>
                    <td><?php echo e($item->funding_type ?? 'Unknown'); ?></td>
                    <td><?php echo e($item->investment_type ?? 'Unknown'); ?></td>
                    <td><?php echo e($item->sender); ?></td>
                    <td><?php echo e($item->origin_bank); ?></td>
                    <td><?php echo e($item->destination_bank); ?></td>
                    <td><?php echo e(ucfirst($item->status)); ?></td>
                    <td class="<?php echo e($item->status === 'approved' ? 'text-success' : 'text-danger'); ?>">
                        <?php echo e(ucfirst($item->status)); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myapp\resources\views/investment/status.blade.php ENDPATH**/ ?>