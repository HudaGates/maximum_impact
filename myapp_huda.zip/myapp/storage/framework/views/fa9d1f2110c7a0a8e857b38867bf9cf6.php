 

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h2 class="fw-bold mb-4">Investment</h2>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="text-center align-middle">
                <tr>
                    <th style="background-color: #1F2A69; color: white; border-top-left-radius: 12px;">Company Name</th>
                    <th style="background-color: #1F2A69; color: white;">Amount</th>
                    <th style="background-color: #1F2A69; color: white;">Investment Date</th>
                    <th style="background-color: #1F2A69; color: white;">Investment Type</th>
                    <th style="background-color: #1F2A69; color: white;">Status</th>
                    <th style="background-color: #1F2A69; color: white;">Action</th>
                    <th style="background-color: #1F2A69; color: white;">Report Financial</th>
                    <th style="background-color: #1F2A69; color: white; border-top-right-radius: 12px;">Report Project</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $investment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->company_name); ?></td>
                    <td>Rp. <?php echo e(number_format($item->amount, 0, ',', '.')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($item->investment_date)->format('j M Y')); ?></td>
                    <td><?php echo e($item->investment_type); ?></td>
                    <td class="text-success fw-semibold">Approved</td>
                    <td><a href="<?php echo e(route('investment.details', $item->id)); ?>" class="text-primary text-decoration-underline">View Details</a></td>
                    <td><button class="btn btn-outline-primary btn-sm">Report Financial</button></td>
                    <td><button class="btn btn-outline-primary btn-sm">Report Project</button></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myapp\resources\views/investment/approve.blade.php ENDPATH**/ ?>