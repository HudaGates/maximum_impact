

<?php $__env->startSection('content'); ?>
    <h6 class="text-uppercase fw-bold">My 6 Month Success Path</h6>
    <div class="mt-4 text-muted">
        <!-- Konten strategi kamu bisa ditambahkan di sini -->
        <p>Strategic path section coming soon...</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myapp\resources\views/strategy/index.blade.php ENDPATH**/ ?>