

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-3">
        <h6>FILTER</h6>
        <div class="mb-3">
            <strong>LOCATION</strong><br>
            <?php $__currentLoopData = ['DKI Jakarta', 'Medan', 'Bandung', 'Surabaya']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="<?php echo e($city); ?>">
                <label class="form0check-label" for="<?php echo e($city); ?>"><?php echo e($city); ?></label>
            </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="#">Others</a>
        </div>

        <div class="mb-3">
            <strong>INVESMENT STAGE</strong><br>
            <?php $__currentLoopData = ['Seed', 'Early Stage Venture', 'Late Stage Venture', 'Private Equity', 'Debt Financing']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="<?php echo e($stage); ?>">
                <label class="form-check-label" for="<?php echo e($stage); ?>"><?php echo e($stage); ?></label>
            </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mb-3">
            <strong>INDUSTRUES</strong><br>
            <span class="badge bg-light text-dark border me-1">Software</span>
            <span class="badge bg-light text-dark border me-1">health Care</span>
            <span class="badge bg-light text-dark border me-1">IT</span>
        </div>
    </div>

    <div class="col-md-9">
        <div class="d-flex justify-content-between mb-3">
            <input type="text" class="form-control w-50" placeholder="Search Data">
            <button class="btn btn-primary">Search></button>
        </div>

        <table class="table table-bordered">
            <thead class="table-dark text-center">
                <tr>
                    <th><input type="checkbox"></th>
                    <th>Organization Name</th>
                    <th>Number of Contacts</th>
                    <th>Number of Invesment</th>
                    <th>Location</th>
                    <th>Description</th>
                    <th>Department</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = range(1, 7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><input type="checkbox"></td>
                    <td><img src="<?php echo e('images/lion.png'); ?>" width="20" class="me-2">Lion Bird</td>
                    <td class="text-center">179</td>
                    <td class="text-center">1,176</td>
                    <td>New York</td>
                    <td>Lorem ipsum dolor sit amet</td>
                    <td>Engineering, Finance, HR</td>
                </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myapp\resources\views/investor/find-investor.blade.php ENDPATH**/ ?>