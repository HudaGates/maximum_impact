@extends('layouts.app')

@section('content')
    <h6 class="text-uppercase fw-bold">My 6 Month Success Path</h6>
    <div class="mt-4 text-muted">
        <!-- Konten strategi kamu bisa ditambahkan di sini -->
        <p>Strategic path section coming soon...</p>
    </div>
@endsection
